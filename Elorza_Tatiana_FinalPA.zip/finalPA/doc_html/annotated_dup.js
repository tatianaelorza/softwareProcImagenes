var annotated_dup =
[
    [ "AdministradorArchivos", "class_administrador_archivos.html", "class_administrador_archivos" ],
    [ "ArchivoAIC", "class_archivo_a_i_c.html", "class_archivo_a_i_c" ],
    [ "ArchivoPNM", "class_archivo_p_n_m.html", "class_archivo_p_n_m" ],
    [ "Deteccion", "class_deteccion.html", "class_deteccion" ],
    [ "Estadistica", "class_estadistica.html", "class_estadistica" ],
    [ "Filtro", "class_filtro.html", "class_filtro" ],
    [ "FiltroMediana", "class_filtro_mediana.html", "class_filtro_mediana" ],
    [ "FiltroPasaAltos", "class_filtro_pasa_altos.html", "class_filtro_pasa_altos" ],
    [ "FiltroPasaBajos", "class_filtro_pasa_bajos.html", "class_filtro_pasa_bajos" ],
    [ "Graficador", "class_graficador.html", "class_graficador" ],
    [ "Imagen", "class_imagen.html", "class_imagen" ],
    [ "Interfaz", "class_interfaz.html", "class_interfaz" ],
    [ "LUT", "class_l_u_t.html", "class_l_u_t" ],
    [ "Pixel", "class_pixel.html", "class_pixel" ],
    [ "QOpenGLFunctions", "class_q_open_g_l_functions.html", null ],
    [ "QOpenGLWidget", "class_q_open_g_l_widget.html", null ],
    [ "Sistema", "class_sistema.html", "class_sistema" ]
];