var class_pixel =
[
    [ "Pixel", "class_pixel.html#a27ad99a2f705e635c42d242d530d4756", null ],
    [ "getB", "class_pixel.html#ac02901ee5a49a57567604c4b8a1731b6", null ],
    [ "getG", "class_pixel.html#a50b393bee1d4717d541c298743d7527d", null ],
    [ "getR", "class_pixel.html#aca9597dec0f29b9240ffa70c7d5f99a9", null ],
    [ "getRGB", "class_pixel.html#a3a58611d4697787fe2436e107778b361", null ],
    [ "modificarRGB", "class_pixel.html#aecb9d92295e0d1080cc2659dd8948432", null ],
    [ "operator*", "class_pixel.html#a7fdf3bd4a6e6e6499b10a4c793f0ac5c", null ],
    [ "operator+", "class_pixel.html#a6474b4d7cf8388f3fc227e9aff7e5d6d", null ],
    [ "operator-", "class_pixel.html#ac76a7a29000fe7597106389b77de0d9a", null ],
    [ "operator==", "class_pixel.html#a3db91f9138b18aa77ff2474013367a55", null ],
    [ "setB", "class_pixel.html#a6a66ecf053011c5bab3436200fec32a2", null ],
    [ "setG", "class_pixel.html#a01adaf721dea66acd3be50a699116e5f", null ],
    [ "setR", "class_pixel.html#a1421d79e623ae7cd3af0e9d8a6a2aeac", null ],
    [ "RGB", "class_pixel.html#a530ed0e6336976145db48365f78bb528", null ]
];