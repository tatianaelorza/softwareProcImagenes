var files =
[
    [ "administradorArchivos.cpp", "administrador_archivos_8cpp.html", null ],
    [ "administradorArchivos.h", "administrador_archivos_8h.html", [
      [ "AdministradorArchivos", "class_administrador_archivos.html", "class_administrador_archivos" ]
    ] ],
    [ "archivoAIC.cpp", "archivo_a_i_c_8cpp.html", null ],
    [ "archivoAIC.h", "archivo_a_i_c_8h.html", [
      [ "ArchivoAIC", "class_archivo_a_i_c.html", "class_archivo_a_i_c" ]
    ] ],
    [ "archivoPNM.cpp", "archivo_p_n_m_8cpp.html", null ],
    [ "archivoPNM.h", "archivo_p_n_m_8h.html", [
      [ "ArchivoPNM", "class_archivo_p_n_m.html", "class_archivo_p_n_m" ]
    ] ],
    [ "deteccion.cpp", "deteccion_8cpp.html", null ],
    [ "deteccion.h", "deteccion_8h.html", [
      [ "Deteccion", "class_deteccion.html", "class_deteccion" ]
    ] ],
    [ "estadistica.cpp", "estadistica_8cpp.html", null ],
    [ "estadistica.h", "estadistica_8h.html", [
      [ "Estadistica", "class_estadistica.html", "class_estadistica" ]
    ] ],
    [ "filtro.cpp", "filtro_8cpp.html", null ],
    [ "filtro.h", "filtro_8h.html", [
      [ "Filtro", "class_filtro.html", "class_filtro" ]
    ] ],
    [ "filtroMediana.cpp", "filtro_mediana_8cpp.html", null ],
    [ "filtroMediana.h", "filtro_mediana_8h.html", [
      [ "FiltroMediana", "class_filtro_mediana.html", "class_filtro_mediana" ]
    ] ],
    [ "filtroPasaAltos.cpp", "filtro_pasa_altos_8cpp.html", null ],
    [ "filtroPasaAltos.h", "filtro_pasa_altos_8h.html", [
      [ "FiltroPasaAltos", "class_filtro_pasa_altos.html", "class_filtro_pasa_altos" ]
    ] ],
    [ "filtroPasaBajos.cpp", "filtro_pasa_bajos_8cpp.html", null ],
    [ "filtroPasaBajos.h", "filtro_pasa_bajos_8h.html", [
      [ "FiltroPasaBajos", "class_filtro_pasa_bajos.html", "class_filtro_pasa_bajos" ]
    ] ],
    [ "graficador.cpp", "graficador_8cpp.html", null ],
    [ "graficador.h", "graficador_8h.html", [
      [ "Graficador", "class_graficador.html", "class_graficador" ]
    ] ],
    [ "imagen.cpp", "imagen_8cpp.html", null ],
    [ "imagen.h", "imagen_8h.html", [
      [ "Imagen", "class_imagen.html", "class_imagen" ]
    ] ],
    [ "interfaz.cpp", "interfaz_8cpp.html", null ],
    [ "interfaz.h", "interfaz_8h.html", [
      [ "Interfaz", "class_interfaz.html", "class_interfaz" ]
    ] ],
    [ "LUT.cpp", "_l_u_t_8cpp.html", null ],
    [ "LUT.h", "_l_u_t_8h.html", [
      [ "LUT", "class_l_u_t.html", "class_l_u_t" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "pagina_principal.h", "pagina__principal_8h.html", null ],
    [ "pixel.cpp", "pixel_8cpp.html", null ],
    [ "pixel.h", "pixel_8h.html", [
      [ "Pixel", "class_pixel.html", "class_pixel" ]
    ] ],
    [ "sistema.cpp", "sistema_8cpp.html", null ],
    [ "sistema.h", "sistema_8h.html", [
      [ "Sistema", "class_sistema.html", "class_sistema" ]
    ] ]
];