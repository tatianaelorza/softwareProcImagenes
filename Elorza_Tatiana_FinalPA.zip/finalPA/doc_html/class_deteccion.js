var class_deteccion =
[
    [ "Deteccion", "class_deteccion.html#a3fc30d65bd3ae388c62ece00ed57cc44", null ],
    [ "algoritmoDelPintor", "class_deteccion.html#a485836bfada18ae05b4e1b133085c19a", null ],
    [ "diferenciaColor", "class_deteccion.html#a35ef1b32c641eebcd9b354a8dd8ffac5", null ],
    [ "getAreaPintada", "class_deteccion.html#a5eac991cc01355ba3c1671234045c40f", null ],
    [ "pintarImagen", "class_deteccion.html#a4ad6dff1797faa5c91f163572a88cf01", null ],
    [ "procesarImagen", "class_deteccion.html#aa37a8cd5138352b6fb644a57f8492acb", null ],
    [ "areaPintada", "class_deteccion.html#af5218920bb5a7cd41bfef30ce30be30c", null ],
    [ "auxImagen", "class_deteccion.html#a3da43d1268ae76917b18e6231015d7aa", null ],
    [ "pixelInicial", "class_deteccion.html#a2d9b56075a7059acbe7b587ceb73e572", null ],
    [ "regionInteres", "class_deteccion.html#aa13d6c1bbe245e4bbf35cf3892588112", null ],
    [ "tolerancia", "class_deteccion.html#a39007ec4f609b2feaf5f3174ae04b075", null ]
];