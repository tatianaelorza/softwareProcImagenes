var class_archivo_p_n_m =
[
    [ "ArchivoPNM", "class_archivo_p_n_m.html#ac00f1568b1a529aebc26cf7df5b2c8e8", null ],
    [ "~ArchivoPNM", "class_archivo_p_n_m.html#aa5deedd740e3c939b63d0e7b56e0ce67", null ],
    [ "escribir", "class_archivo_p_n_m.html#a48ed21fb7ce83aa3650d4a416e1433a9", null ],
    [ "getTipoArchivo", "class_archivo_p_n_m.html#a1c12b86ea29b606445db08a1b78c2636", null ],
    [ "leer", "class_archivo_p_n_m.html#af6e665a8d1e27633e82cb223a624f0e8", null ],
    [ "tipoArchivo", "class_archivo_p_n_m.html#a5533b4ecaf99d04cbf3dc2e1e8ecea97", null ]
];