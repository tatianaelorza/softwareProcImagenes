var class_l_u_t =
[
    [ "LUT", "class_l_u_t.html#a5fd7a4d70905dd7b338a3af054ca1619", null ],
    [ "leerArchivoLUT", "class_l_u_t.html#a701a80dc6ccc2418529717c62ba1567d", null ],
    [ "pseudocolorear", "class_l_u_t.html#a9270a36202c635c716d112c7383a0bc7", null ],
    [ "matrizLUT", "class_l_u_t.html#ac35c8df998fd689e46f83c05bb830a2a", null ]
];