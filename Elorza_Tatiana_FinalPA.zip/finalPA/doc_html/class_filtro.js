var class_filtro =
[
    [ "Filtro", "class_filtro.html#aca57ca50973ca2a5b6df25f986d4de90", null ],
    [ "~Filtro", "class_filtro.html#adc7b27965edef6f6e9cb6bd261e031bd", null ],
    [ "procesarImagen", "class_filtro.html#ae523b99c74e5e0c2ef39492656452dd5", null ]
];