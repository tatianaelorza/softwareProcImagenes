var class_filtro_pasa_altos =
[
    [ "FiltroPasaAltos", "class_filtro_pasa_altos.html#a4858f94102cae7d5ec35c9d9a86e8735", null ],
    [ "procesarImagen", "class_filtro_pasa_altos.html#a55a5f1d5f13d54eacd5932d72a3d45fe", null ]
];