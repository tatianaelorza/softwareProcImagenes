var class_filtro_pasa_bajos =
[
    [ "FiltroPasaBajos", "class_filtro_pasa_bajos.html#afc656698fc72c1ec398356a27f3fa931", null ],
    [ "procesarImagen", "class_filtro_pasa_bajos.html#a764f7fe2376edc2d31f66b9775117d4c", null ]
];