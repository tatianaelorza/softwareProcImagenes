var class_interfaz =
[
    [ "Interfaz", "class_interfaz.html#a0f6a43c3b126a113bf0b01a6ae8051bc", null ],
    [ "~Interfaz", "class_interfaz.html#ab94218d7c78e56b82424c0825dcd50c6", null ],
    [ "getListaDeAtajos", "class_interfaz.html#a6d01545c8a4ca17a54eccaf2a43765de", null ],
    [ "getListadoDeArchivos", "class_interfaz.html#a7d7235ed5b5f6af6e6581bb9c3b5a22e", null ],
    [ "guardarImagen", "class_interfaz.html#a2d896a0a70d537f936f87d42f1b1dbc0", null ],
    [ "archi", "class_interfaz.html#a78b7d2860fb2c636a8c7d54c0cc7eb59", null ],
    [ "imagen", "class_interfaz.html#a6cc068712b1b6c652d77488958baf45e", null ],
    [ "nombreDelArchivoNuevo", "class_interfaz.html#ac0b2b06f0ff02c15a95f4988fc90d51b", null ],
    [ "opcArchivoNuevo", "class_interfaz.html#a6a5501d49d8e09bed4e4813dd6dd1a0e", null ],
    [ "opcTipoArchivoPNM", "class_interfaz.html#abcd3e6409615b3bfb7c2ef9a252f670a", null ],
    [ "raiz", "class_interfaz.html#a3d3b04e6eade8102e5c30d350c516b5f", null ],
    [ "rutaArchivosNuevos", "class_interfaz.html#a08a0e1eb6762a6d804e78d86e52a5ded", null ]
];