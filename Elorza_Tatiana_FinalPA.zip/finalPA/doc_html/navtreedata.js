var NAVTREE =
[
  [ "Mi Proyecto de Prog. Avanzada (busca esto en el archivo  doxy.config si quieres modificarlo...)", "index.html", [
    [ "Nombre-de-sección-SIN-espacios", "index.html#Nombre-de-sección-SIN-espacios", null ],
    [ "Título-para-la-segunda-sección", "index.html#Título-para-la-segunda-sección", null ],
    [ "Estructuras de Datos", "annotated.html", [
      [ "Estructura de datos", "annotated.html", "annotated_dup" ],
      [ "Índice de estructura de datos", "classes.html", null ],
      [ "Jerarquía de la clase", "hierarchy.html", "hierarchy" ],
      [ "Campos de datos", "functions.html", [
        [ "Todo", "functions.html", "functions_dup" ],
        [ "Funciones", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Archivos", null, [
      [ "Lista de archivos", "files.html", "files" ],
      [ "Globales", "globals.html", [
        [ "Todo", "globals.html", null ],
        [ "Funciones", "globals_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_l_u_t_8cpp.html",
"class_sistema.html"
];

var SYNCONMSG = 'click en deshabilitar sincronización';
var SYNCOFFMSG = 'click en habilitar sincronización';