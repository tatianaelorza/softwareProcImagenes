var class_filtro_mediana =
[
    [ "FiltroMediana", "class_filtro_mediana.html#aee242c22d3f05be85f85ebab2737d256", null ],
    [ "procesarImagen", "class_filtro_mediana.html#aa6f24d75ae86c64d129bc858b58c640e", null ]
];