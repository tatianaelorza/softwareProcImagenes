var hierarchy =
[
    [ "AdministradorArchivos", "class_administrador_archivos.html", [
      [ "ArchivoAIC", "class_archivo_a_i_c.html", null ],
      [ "ArchivoPNM", "class_archivo_p_n_m.html", null ]
    ] ],
    [ "Deteccion", "class_deteccion.html", null ],
    [ "Estadistica", "class_estadistica.html", null ],
    [ "Filtro", "class_filtro.html", [
      [ "FiltroMediana", "class_filtro_mediana.html", null ],
      [ "FiltroPasaAltos", "class_filtro_pasa_altos.html", null ],
      [ "FiltroPasaBajos", "class_filtro_pasa_bajos.html", null ]
    ] ],
    [ "Imagen", "class_imagen.html", null ],
    [ "Interfaz", "class_interfaz.html", null ],
    [ "LUT", "class_l_u_t.html", null ],
    [ "Pixel", "class_pixel.html", null ],
    [ "QOpenGLFunctions", "class_q_open_g_l_functions.html", [
      [ "Graficador", "class_graficador.html", null ]
    ] ],
    [ "QOpenGLWidget", "class_q_open_g_l_widget.html", [
      [ "Graficador", "class_graficador.html", null ]
    ] ],
    [ "Sistema", "class_sistema.html", null ]
];