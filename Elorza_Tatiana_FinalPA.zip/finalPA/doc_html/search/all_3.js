var searchData=
[
  ['desplazamientox',['desplazamientoX',['../class_graficador.html#a8dec75196af08186725fc7b666c8c1fa',1,'Graficador']]],
  ['desplazamientoy',['desplazamientoY',['../class_graficador.html#a2cdc6196525b3f9fc9140a5c25e7ec88',1,'Graficador']]],
  ['desviacionestandar',['desviacionEstandar',['../class_estadistica.html#a850647f9e3dedfca22fff6695fa27bca',1,'Estadistica']]],
  ['deteccion',['Deteccion',['../class_deteccion.html',1,'Deteccion'],['../class_graficador.html#a3068af44859650771700dc54476a0a61',1,'Graficador::deteccion()'],['../class_deteccion.html#a3fc30d65bd3ae388c62ece00ed57cc44',1,'Deteccion::Deteccion()']]],
  ['deteccion_2ecpp',['deteccion.cpp',['../deteccion_8cpp.html',1,'']]],
  ['deteccion_2eh',['deteccion.h',['../deteccion_8h.html',1,'']]],
  ['diferenciacolor',['diferenciaColor',['../class_deteccion.html#a35ef1b32c641eebcd9b354a8dd8ffac5',1,'Deteccion']]],
  ['directorio',['directorio',['../class_sistema.html#a42fe8108a30df34c18d7410dfecae4ee',1,'Sistema']]],
  ['directoriolut1',['directorioLUT1',['../class_sistema.html#aa740e3ab008c841277fc2fa490acc8fd',1,'Sistema']]],
  ['directoriolut2',['directorioLUT2',['../class_sistema.html#a8d0829671ba28710a7a17725ec4320ed',1,'Sistema']]]
];
