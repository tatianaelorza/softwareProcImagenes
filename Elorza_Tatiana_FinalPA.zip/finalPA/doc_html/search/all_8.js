var searchData=
[
  ['imagen',['Imagen',['../class_imagen.html',1,'Imagen'],['../class_estadistica.html#abcff45fcc347e6b51e48488525f940c7',1,'Estadistica::imagen()'],['../class_graficador.html#a6f115fb6ae2d797c0e5fe5ead83fd3e5',1,'Graficador::imagen()'],['../class_imagen.html#a8c224005aefe52abc5195a0b06804d88',1,'Imagen::imagen()'],['../class_interfaz.html#a6cc068712b1b6c652d77488958baf45e',1,'Interfaz::imagen()'],['../class_imagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()']]],
  ['imagen_2ecpp',['imagen.cpp',['../imagen_8cpp.html',1,'']]],
  ['imagen_2eh',['imagen.h',['../imagen_8h.html',1,'']]],
  ['imagenoriginal',['imagenOriginal',['../class_graficador.html#a523a87ec13e91fb5785b85d600eb8c0f',1,'Graficador']]],
  ['indiceimagen',['indiceImagen',['../class_graficador.html#ab9ff96f635b7979a3c750c9db9beba0f',1,'Graficador']]],
  ['indicelut',['indiceLUT',['../class_graficador.html#a9a01e356d5392731d9cd2baa23ba7fe6',1,'Graficador']]],
  ['informardatos',['informarDatos',['../class_estadistica.html#adeafbb23b51da9aa7b72e4285f088352',1,'Estadistica']]],
  ['initializegl',['initializeGL',['../class_graficador.html#a4ab8a3cdaa9bc1cca5f619c908407a1f',1,'Graficador']]],
  ['interfaz',['Interfaz',['../class_interfaz.html',1,'Interfaz'],['../class_graficador.html#a1d94935fa1dc5f2ea00f2d159e15f8a1',1,'Graficador::interfaz()'],['../class_sistema.html#a9f683fa4898217bbdfe6bfaaff7f9c76',1,'Sistema::interfaz()'],['../class_interfaz.html#a0f6a43c3b126a113bf0b01a6ae8051bc',1,'Interfaz::Interfaz()']]],
  ['interfaz_2ecpp',['interfaz.cpp',['../interfaz_8cpp.html',1,'']]],
  ['interfaz_2eh',['interfaz.h',['../interfaz_8h.html',1,'']]]
];
