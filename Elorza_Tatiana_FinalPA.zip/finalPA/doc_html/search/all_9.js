var searchData=
[
  ['keypressevent',['keyPressEvent',['../class_graficador.html#a212ae0da32da28e55eb959bbea6d4ad6',1,'Graficador']]],
  ['keyreleaseevent',['keyReleaseEvent',['../class_graficador.html#a46cc92f09caae0921860425805c984a7',1,'Graficador']]]
];
