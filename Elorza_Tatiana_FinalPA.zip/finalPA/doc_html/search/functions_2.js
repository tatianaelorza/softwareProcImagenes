var searchData=
[
  ['cambiarbrillo',['cambiarBrillo',['../class_imagen.html#aa8b7a9cb3deb54d09aaa97c0287d272d',1,'Imagen']]],
  ['controlmaxrangodinamico',['controlMaxRangoDinamico',['../class_imagen.html#abe9563f4611d21fcf0504437a57fb759',1,'Imagen']]]
];
