var searchData=
[
  ['negativizarimagen',['negativizarImagen',['../class_imagen.html#ac6412de115c250b06cae00860a973524',1,'Imagen']]],
  ['nombredelarchivonuevo',['nombreDelArchivoNuevo',['../class_interfaz.html#ac0b2b06f0ff02c15a95f4988fc90d51b',1,'Interfaz']]],
  ['npresionada',['nPresionada',['../class_graficador.html#aabf7b999b9319d28269c1fa26287be76',1,'Graficador']]]
];
