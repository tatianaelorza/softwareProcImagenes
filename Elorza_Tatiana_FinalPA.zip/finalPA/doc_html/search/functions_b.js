var searchData=
[
  ['negativizarimagen',['negativizarImagen',['../class_imagen.html#ac6412de115c250b06cae00860a973524',1,'Imagen']]]
];
