var searchData=
[
  ['filtro',['Filtro',['../class_filtro.html#aca57ca50973ca2a5b6df25f986d4de90',1,'Filtro']]],
  ['filtromediana',['FiltroMediana',['../class_filtro_mediana.html#aee242c22d3f05be85f85ebab2737d256',1,'FiltroMediana']]],
  ['filtropasaaltos',['FiltroPasaAltos',['../class_filtro_pasa_altos.html#a4858f94102cae7d5ec35c9d9a86e8735',1,'FiltroPasaAltos']]],
  ['filtropasabajos',['FiltroPasaBajos',['../class_filtro_pasa_bajos.html#afc656698fc72c1ec398356a27f3fa931',1,'FiltroPasaBajos']]]
];
