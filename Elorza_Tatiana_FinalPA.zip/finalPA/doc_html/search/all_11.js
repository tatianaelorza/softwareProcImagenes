var searchData=
[
  ['setaltoimagen',['setAltoImagen',['../class_imagen.html#a485630ab889c71d93ff35c5d9ab71871',1,'Imagen']]],
  ['setanchoimagen',['setAnchoImagen',['../class_imagen.html#a6c099eeeff7ff61af5af058b32743f71',1,'Imagen']]],
  ['setb',['setB',['../class_pixel.html#a6a66ecf053011c5bab3436200fec32a2',1,'Pixel']]],
  ['setg',['setG',['../class_pixel.html#a01adaf721dea66acd3be50a699116e5f',1,'Pixel']]],
  ['setimagen',['setImagen',['../class_estadistica.html#a46099fa48e6bb93075394bf6c874f5e3',1,'Estadistica::setImagen()'],['../class_graficador.html#a9aaa7e15039ca6693fc0da72bae970f1',1,'Graficador::setImagen()']]],
  ['setlistadoimagenes',['setListadoImagenes',['../class_graficador.html#a7ec0825d7f1a9e0d11d0f177c2e9e14b',1,'Graficador']]],
  ['setlistadolut',['setListadoLUT',['../class_graficador.html#ad58d5cafc4546df48242656f68706b63',1,'Graficador']]],
  ['setmaxrangodinamico',['setMaxRangoDinamico',['../class_imagen.html#a0bcda8813cd1769d63e17fdf9b0cb33d',1,'Imagen']]],
  ['setmetadatos',['setMetadatos',['../class_imagen.html#ad9d36abb26325fc8248637d4e577114a',1,'Imagen']]],
  ['setpixel',['setPixel',['../class_imagen.html#a2dc48d98d687261d264bbd2a28e13cb9',1,'Imagen']]],
  ['setr',['setR',['../class_pixel.html#a1421d79e623ae7cd3af0e9d8a6a2aeac',1,'Pixel']]],
  ['sistema',['Sistema',['../class_sistema.html',1,'Sistema'],['../class_sistema.html#a815b07845ef6b03247b239333fe75e28',1,'Sistema::Sistema()']]],
  ['sistema_2ecpp',['sistema.cpp',['../sistema_8cpp.html',1,'']]],
  ['sistema_2eh',['sistema.h',['../sistema_8h.html',1,'']]],
  ['spresionada',['sPresionada',['../class_graficador.html#a0c609e704096cb369dd385b7dd360069',1,'Graficador']]]
];
