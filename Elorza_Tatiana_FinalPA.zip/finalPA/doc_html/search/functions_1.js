var searchData=
[
  ['binarizarimagen',['binarizarImagen',['../class_imagen.html#a8b13cccfc840b4e62f1bfa0cf6f87262',1,'Imagen']]]
];
