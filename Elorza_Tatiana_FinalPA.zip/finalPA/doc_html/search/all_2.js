var searchData=
[
  ['cambiarbrillo',['cambiarBrillo',['../class_imagen.html#aa8b7a9cb3deb54d09aaa97c0287d272d',1,'Imagen']]],
  ['clickizquierdopresionado',['clickIzquierdoPresionado',['../class_graficador.html#ad8ceacb1b87c4ab057a0bdbccd6b9975',1,'Graficador']]],
  ['controlgraficarhistograma',['controlGraficarHistograma',['../class_graficador.html#a079f6d4115d1cb5d32d04cfc8029bd3d',1,'Graficador']]],
  ['controlgraficarzoom',['controlGraficarZoom',['../class_graficador.html#a1448066dae8b6300a49a8fcd7478dd94',1,'Graficador']]],
  ['controlmaxrangodinamico',['controlMaxRangoDinamico',['../class_imagen.html#abe9563f4611d21fcf0504437a57fb759',1,'Imagen']]],
  ['controlmousemove',['controlMouseMove',['../class_graficador.html#a86967d582ce3b2d1cec84075b86a583e',1,'Graficador']]],
  ['controlpresionado',['controlPresionado',['../class_graficador.html#af5332a8192e79cf7aeb0ed6c9f976fff',1,'Graficador']]],
  ['cpresionada',['cPresionada',['../class_graficador.html#adb8b6cec443078c59aab90464851b63f',1,'Graficador']]]
];
