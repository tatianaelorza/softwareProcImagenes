var searchData=
[
  ['estadistica',['Estadistica',['../class_estadistica.html',1,'']]]
];
