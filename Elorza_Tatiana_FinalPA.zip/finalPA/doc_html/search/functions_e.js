var searchData=
[
  ['resizegl',['resizeGL',['../class_graficador.html#a0325462a2df57cf15cd6791750f46937',1,'Graficador']]]
];
