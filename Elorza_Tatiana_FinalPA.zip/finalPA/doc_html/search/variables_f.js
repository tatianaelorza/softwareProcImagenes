var searchData=
[
  ['spresionada',['sPresionada',['../class_graficador.html#a0c609e704096cb369dd385b7dd360069',1,'Graficador']]]
];
