var searchData=
[
  ['opcarchivonuevo',['opcArchivoNuevo',['../class_interfaz.html#a6a5501d49d8e09bed4e4813dd6dd1a0e',1,'Interfaz']]],
  ['opciondirectorio',['opcionDirectorio',['../class_sistema.html#a5348ae6ededeb270e7374a1acf5b82c7',1,'Sistema']]],
  ['opcionimagen',['opcionImagen',['../class_sistema.html#a1adc4f70dc080ab376e8d58de17566c1',1,'Sistema']]],
  ['opcionlut',['opcionLUT',['../class_graficador.html#adcb4ac5ce30c944a12dbdd3d1d4311ef',1,'Graficador::opcionLUT()'],['../class_sistema.html#a7ff00a3536d33bbaa306e86b0967a311',1,'Sistema::opcionLUT()']]],
  ['opcionmenu',['opcionMenu',['../class_sistema.html#a5c323d8c735b9182207576cf30e3d3f4',1,'Sistema']]],
  ['opctipoarchivopnm',['opcTipoArchivoPNM',['../class_interfaz.html#abcd3e6409615b3bfb7c2ef9a252f670a',1,'Interfaz']]],
  ['opresionada',['oPresionada',['../class_graficador.html#a1442932f1566aa089618d7cb70805725',1,'Graficador']]]
];
