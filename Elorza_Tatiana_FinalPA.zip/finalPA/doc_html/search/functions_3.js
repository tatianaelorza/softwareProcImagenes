var searchData=
[
  ['deteccion',['Deteccion',['../class_deteccion.html#a3fc30d65bd3ae388c62ece00ed57cc44',1,'Deteccion']]],
  ['diferenciacolor',['diferenciaColor',['../class_deteccion.html#a35ef1b32c641eebcd9b354a8dd8ffac5',1,'Deteccion']]]
];
