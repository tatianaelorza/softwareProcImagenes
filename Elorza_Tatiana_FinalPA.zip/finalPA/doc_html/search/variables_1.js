var searchData=
[
  ['bpresionada',['bPresionada',['../class_graficador.html#aa9602d091f532f82a60aaeec845e8a50',1,'Graficador']]]
];
