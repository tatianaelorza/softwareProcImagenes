var searchData=
[
  ['tipoarchivo',['tipoArchivo',['../class_archivo_a_i_c.html#a813a70c6937a077963bed2bceedea8eb',1,'ArchivoAIC::tipoArchivo()'],['../class_archivo_p_n_m.html#a5533b4ecaf99d04cbf3dc2e1e8ecea97',1,'ArchivoPNM::tipoArchivo()']]],
  ['tolerancia',['tolerancia',['../class_deteccion.html#a39007ec4f609b2feaf5f3174ae04b075',1,'Deteccion::tolerancia()'],['../class_graficador.html#a3de1cfb432c752e5d791d32186dc460b',1,'Graficador::tolerancia()']]]
];
