var searchData=
[
  ['pixelinicial',['pixelInicial',['../class_deteccion.html#a2d9b56075a7059acbe7b587ceb73e572',1,'Deteccion']]],
  ['pluspresionada',['plusPresionada',['../class_graficador.html#a73ad85e1b21ddee6e3aa58cfec5d1363',1,'Graficador']]],
  ['posicionfinalx',['posicionFinalX',['../class_graficador.html#aa6529368b39621be3e9eeb886efcfa20',1,'Graficador']]],
  ['posicionfinaly',['posicionFinalY',['../class_graficador.html#a327398c850bc601be1f3a3ce44999642',1,'Graficador']]],
  ['posicioninicialx',['posicionInicialX',['../class_graficador.html#a926a63d2591f19edbbdd26ebbacb6d47',1,'Graficador']]],
  ['posicioninicialy',['posicionInicialY',['../class_graficador.html#a29c349d685c6039b271bf89a561989bd',1,'Graficador']]],
  ['posicionmomentaneax',['posicionMomentaneaX',['../class_graficador.html#ac05a2bccdcec421e713e0dbcd79dd7c1',1,'Graficador']]],
  ['posicionmomentaneay',['posicionMomentaneaY',['../class_graficador.html#ae8d38670b13f80896d6111d24c384a88',1,'Graficador']]],
  ['posicionventanafinalx',['posicionVentanaFinalX',['../class_graficador.html#a678de974ff1ecc52977f07f02ddf17fe',1,'Graficador']]],
  ['posicionventanafinaly',['posicionVentanaFinalY',['../class_graficador.html#a6d7ed67ca5c691d607a3e3f51e00d7e7',1,'Graficador']]],
  ['posicionventanainicialx',['posicionVentanaInicialX',['../class_graficador.html#a484daad763ba5141dd42e7dfecf16341',1,'Graficador']]],
  ['posicionventanainicialy',['posicionVentanaInicialY',['../class_graficador.html#ab3ac314f63266759af6999d44cdc97a9',1,'Graficador']]],
  ['promedio',['promedio',['../class_estadistica.html#a898f490804b0b7bc15f67e017b3e1a24',1,'Estadistica']]],
  ['promediointensidades',['promedioIntensidades',['../class_estadistica.html#a5769cc07c8bba9face0ab7bcdebbbee2',1,'Estadistica']]]
];
