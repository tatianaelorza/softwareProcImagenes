var searchData=
[
  ['imagen',['Imagen',['../class_imagen.html',1,'']]],
  ['interfaz',['Interfaz',['../class_interfaz.html',1,'']]]
];
