var searchData=
[
  ['deteccion',['Deteccion',['../class_deteccion.html',1,'']]]
];
