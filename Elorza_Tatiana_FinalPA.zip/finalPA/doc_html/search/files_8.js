var searchData=
[
  ['pagina_5fprincipal_2eh',['pagina_principal.h',['../pagina__principal_8h.html',1,'']]],
  ['pixel_2ecpp',['pixel.cpp',['../pixel_8cpp.html',1,'']]],
  ['pixel_2eh',['pixel.h',['../pixel_8h.html',1,'']]]
];
