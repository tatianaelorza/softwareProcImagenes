var searchData=
[
  ['imagen',['imagen',['../class_estadistica.html#abcff45fcc347e6b51e48488525f940c7',1,'Estadistica::imagen()'],['../class_graficador.html#a6f115fb6ae2d797c0e5fe5ead83fd3e5',1,'Graficador::imagen()'],['../class_imagen.html#a8c224005aefe52abc5195a0b06804d88',1,'Imagen::imagen()'],['../class_interfaz.html#a6cc068712b1b6c652d77488958baf45e',1,'Interfaz::imagen()']]],
  ['imagenoriginal',['imagenOriginal',['../class_graficador.html#a523a87ec13e91fb5785b85d600eb8c0f',1,'Graficador']]],
  ['indiceimagen',['indiceImagen',['../class_graficador.html#ab9ff96f635b7979a3c750c9db9beba0f',1,'Graficador']]],
  ['indicelut',['indiceLUT',['../class_graficador.html#a9a01e356d5392731d9cd2baa23ba7fe6',1,'Graficador']]],
  ['interfaz',['interfaz',['../class_graficador.html#a1d94935fa1dc5f2ea00f2d159e15f8a1',1,'Graficador::interfaz()'],['../class_sistema.html#a9f683fa4898217bbdfe6bfaaff7f9c76',1,'Sistema::interfaz()']]]
];
