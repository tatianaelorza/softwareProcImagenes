var searchData=
[
  ['operator_2a',['operator*',['../class_pixel.html#a7fdf3bd4a6e6e6499b10a4c793f0ac5c',1,'Pixel']]],
  ['operator_2b',['operator+',['../class_pixel.html#a6474b4d7cf8388f3fc227e9aff7e5d6d',1,'Pixel']]],
  ['operator_2d',['operator-',['../class_pixel.html#ac76a7a29000fe7597106389b77de0d9a',1,'Pixel']]],
  ['operator_3d_3d',['operator==',['../class_pixel.html#a3db91f9138b18aa77ff2474013367a55',1,'Pixel']]]
];
