var searchData=
[
  ['paintgl',['paintGL',['../class_graficador.html#ae4688453e2b0aaff457a17b0a29f1ba5',1,'Graficador']]],
  ['pintarimagen',['pintarImagen',['../class_deteccion.html#a4ad6dff1797faa5c91f163572a88cf01',1,'Deteccion']]],
  ['pixel',['Pixel',['../class_pixel.html#a27ad99a2f705e635c42d242d530d4756',1,'Pixel']]],
  ['procesarimagen',['procesarImagen',['../class_deteccion.html#aa37a8cd5138352b6fb644a57f8492acb',1,'Deteccion::procesarImagen()'],['../class_estadistica.html#a54c4ac2c9a008bc43f5a85bba19d0616',1,'Estadistica::procesarImagen()'],['../class_filtro.html#ae523b99c74e5e0c2ef39492656452dd5',1,'Filtro::procesarImagen()'],['../class_filtro_mediana.html#aa6f24d75ae86c64d129bc858b58c640e',1,'FiltroMediana::procesarImagen()'],['../class_filtro_pasa_altos.html#a55a5f1d5f13d54eacd5932d72a3d45fe',1,'FiltroPasaAltos::procesarImagen()'],['../class_filtro_pasa_bajos.html#a764f7fe2376edc2d31f66b9775117d4c',1,'FiltroPasaBajos::procesarImagen()']]],
  ['pseudocolorear',['pseudocolorear',['../class_l_u_t.html#a9270a36202c635c716d112c7383a0bc7',1,'LUT']]]
];
