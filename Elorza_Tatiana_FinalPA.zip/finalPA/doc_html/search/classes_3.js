var searchData=
[
  ['filtro',['Filtro',['../class_filtro.html',1,'']]],
  ['filtromediana',['FiltroMediana',['../class_filtro_mediana.html',1,'']]],
  ['filtropasaaltos',['FiltroPasaAltos',['../class_filtro_pasa_altos.html',1,'']]],
  ['filtropasabajos',['FiltroPasaBajos',['../class_filtro_pasa_bajos.html',1,'']]]
];
