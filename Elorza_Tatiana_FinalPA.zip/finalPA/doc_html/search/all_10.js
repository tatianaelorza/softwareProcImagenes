var searchData=
[
  ['raiz',['raiz',['../class_interfaz.html#a3d3b04e6eade8102e5c30d350c516b5f',1,'Interfaz']]],
  ['regioninteres',['regionInteres',['../class_deteccion.html#aa13d6c1bbe245e4bbf35cf3892588112',1,'Deteccion']]],
  ['resizegl',['resizeGL',['../class_graficador.html#a0325462a2df57cf15cd6791750f46937',1,'Graficador']]],
  ['rgb',['RGB',['../class_pixel.html#a530ed0e6336976145db48365f78bb528',1,'Pixel']]],
  ['rutaarchivoscarpeta1',['rutaArchivosCarpeta1',['../class_sistema.html#a288961ddc8eb9975b9519567d89cc659',1,'Sistema']]],
  ['rutaarchivoscarpeta2',['rutaArchivosCarpeta2',['../class_sistema.html#a8321d6fb1535f3c8316a57d9a4883ebe',1,'Sistema']]],
  ['rutaarchivoscarpeta3',['rutaArchivosCarpeta3',['../class_sistema.html#aca835cbfcae6672a1cf753a940fcc699',1,'Sistema']]],
  ['rutaarchivoscarpeta5',['rutaArchivosCarpeta5',['../class_sistema.html#ae7f459b83330328fe37c7c660d63b94d',1,'Sistema']]],
  ['rutaarchivosnuevos',['rutaArchivosNuevos',['../class_interfaz.html#a08a0e1eb6762a6d804e78d86e52a5ded',1,'Interfaz::rutaArchivosNuevos()'],['../class_sistema.html#aa29ce82b7c5cb4914073875ee6b88a94',1,'Sistema::rutaArchivosNuevos()']]]
];
