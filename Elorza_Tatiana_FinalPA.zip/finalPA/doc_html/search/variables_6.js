var searchData=
[
  ['gpresionada',['gPresionada',['../class_graficador.html#acd02387629f1bdfa5294ad6f257c94f4',1,'Graficador']]],
  ['graficador',['graficador',['../class_sistema.html#a9ef4c8faf6af11017cf28dd7f73b3e0e',1,'Sistema']]]
];
