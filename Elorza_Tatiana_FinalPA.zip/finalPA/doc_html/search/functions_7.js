var searchData=
[
  ['imagen',['Imagen',['../class_imagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen']]],
  ['informardatos',['informarDatos',['../class_estadistica.html#adeafbb23b51da9aa7b72e4285f088352',1,'Estadistica']]],
  ['initializegl',['initializeGL',['../class_graficador.html#a4ab8a3cdaa9bc1cca5f619c908407a1f',1,'Graficador']]],
  ['interfaz',['Interfaz',['../class_interfaz.html#a0f6a43c3b126a113bf0b01a6ae8051bc',1,'Interfaz']]]
];
