var searchData=
[
  ['estadistica_2ecpp',['estadistica.cpp',['../estadistica_8cpp.html',1,'']]],
  ['estadistica_2eh',['estadistica.h',['../estadistica_8h.html',1,'']]]
];
