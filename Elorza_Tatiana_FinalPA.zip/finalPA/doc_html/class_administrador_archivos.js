var class_administrador_archivos =
[
    [ "AdministradorArchivos", "class_administrador_archivos.html#a12a643eb9c71c56878fd2f1b11881772", null ],
    [ "~AdministradorArchivos", "class_administrador_archivos.html#acbc5a76791ea2d35d157b8c71e38ece3", null ],
    [ "escribir", "class_administrador_archivos.html#a604ca4cfdd1ed0220a40fe595896e92d", null ],
    [ "getTipoArchivo", "class_administrador_archivos.html#a2f676d0926132d6d1cb6649a277499ea", null ],
    [ "leer", "class_administrador_archivos.html#a51f58dcd3714335148488c74d476360a", null ]
];