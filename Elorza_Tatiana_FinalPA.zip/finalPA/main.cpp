#include <QCoreApplication>
#include <imagen.h>
#include <administradorArchivos.h>
#include <archivoPNM.h>
#include <graficador.h>
#include <interfaz.h>
#include <sistema.h>
#include <LUT.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    Sistema sis;

    sis.ejecutar();


    return a.exec();
}
