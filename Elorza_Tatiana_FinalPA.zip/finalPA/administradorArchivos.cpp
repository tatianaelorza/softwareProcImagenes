#include "administradorArchivos.h"
AdministradorArchivos::AdministradorArchivos()
{

}
AdministradorArchivos::~AdministradorArchivos()
{

}
