#include "deteccion.h"
Deteccion::Deteccion(){

}
void Deteccion::procesarImagen(int pFila, int pColumna, Imagen *pImagen)
{
    regionInteres.clear();
    areaPintada=0;
    auxImagen=pImagen;

    regionInteres.resize(auxImagen->getAltoImagen(), vector<bool>(auxImagen->getAnchoImagen(),false));
    tolerancia =0.15;
    pixelInicial=auxImagen->getPixel(pFila,pColumna);
    algoritmoDelPintor(pFila,pColumna,1);
    algoritmoDelPintor(pFila,pColumna-1,2);

    pintarImagen();
}
void Deteccion::algoritmoDelPintor(int pFila, int pColumna, char pLado)
{
    int &fila = pFila;

    int &columna = pColumna;

    if(fila < auxImagen->getAltoImagen() and columna < auxImagen->getAnchoImagen())
    {
        if(diferenciaColor(pixelInicial, auxImagen->getPixel(fila, columna),auxImagen->getMaxRangoDinamico())<= tolerancia and regionInteres[fila][columna]==false)
        {
            regionInteres[fila][columna] = true;
            ++areaPintada;

            if(pLado == 1)
            {
                algoritmoDelPintor(fila-1,columna-1,pLado);
                algoritmoDelPintor(fila-1,columna,pLado);
                algoritmoDelPintor(fila-1,columna+1,pLado);
                algoritmoDelPintor(fila,columna+1,pLado);
                algoritmoDelPintor(fila+1,columna+1,pLado);
            }else if(pLado == 2)
            {
                algoritmoDelPintor(fila-1,columna-1,pLado);
                algoritmoDelPintor(fila+1,columna,pLado);
                algoritmoDelPintor(fila+1,columna-1,pLado);
                algoritmoDelPintor(fila,columna-1,pLado);
                algoritmoDelPintor(fila+1,columna+1,pLado);
            }
        }
    }
}
int Deteccion::getAreaPintada()
{
    return areaPintada;
}
void Deteccion::pintarImagen()
{
    Pixel pixel;
    for(int i = 0; i<auxImagen->getAltoImagen(); i++)
    {
        for(int j = 0; j<auxImagen->getAnchoImagen(); j++)
        {
            pixel = auxImagen->getPixel(i,j);

            if(regionInteres[i][j] == true)
            {
               auxImagen->modificarRGBij(i,j,255.0,255.0,0.0);
            }
        }
    }
}
float Deteccion::diferenciaColor(Pixel pPixel1, Pixel pPixel2, int maxRangoDinamico)
{
    int aux=0;
    aux=(pPixel1.getR()/(float)maxRangoDinamico-pPixel2.getR()/(float)maxRangoDinamico)+(pPixel1.getG()/(float)maxRangoDinamico-pPixel2.getG()/(float)maxRangoDinamico)+(pPixel1.getB()/(float)maxRangoDinamico-pPixel2.getB()/(float)maxRangoDinamico);

    return aux;
}
