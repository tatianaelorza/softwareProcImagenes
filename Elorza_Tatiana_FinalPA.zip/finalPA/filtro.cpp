#include "filtro.h"

Filtro::Filtro()
{

}
Filtro::~Filtro()
{

}
